module.exports = {
    mqtt: {
        port: 3001,
        host: 'localhost',
        http: {port: 3002, bundle: true, static: './'}  
    }
}
